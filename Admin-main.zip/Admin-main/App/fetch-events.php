<?php
$arrayVar = [
    [
        "title" => "Meeting with Client",
        "start" => "2025-05-12T10:00:00",
        "end" => "2025-05-12T11:30:00",
    ],
    [
        "title" => "Team Standup",
        "start" => "2025-05-13T09:00:00",
        "end" => "2025-05-13T09:30:00",
    ],
    [
        "title" => "Project Deadline",
        "start" => "2025-05-13T09:00:00",
        "end" => "2025-05-13T09:30:00",
    ],
    [
        "title" => "Team Standup",
        "start" => "2025-05-13T09:00:00",
        "end" => "2025-05-13T09:30:00",
    ],
    [
        "title" => "Project Deadline",
        "start" => "2025-05-13T09:00:00",
        "end" => "2025-05-13T09:30:00",
    ],
];

echo json_encode($arrayVar);
?>