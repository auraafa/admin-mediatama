<a href="index3.html" class="brand-link">
      <img src="../image 33.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text"><span style="font-weight: 700;">Mediatama</span> <span style="font-weight: 300;">Web</span></span>
    </a>